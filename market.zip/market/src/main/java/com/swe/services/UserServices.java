package com.swe.services;

import com.swe.model.IUser;
import com.swe.repository.IUserRepo;

import java.sql.SQLException;
import java.util.List;

public class UserServices implements IUserServices {
   // @Autowired
    IUserRepo repository;

    public UserServices(IUserRepo repository) {
        this.repository = repository;
    }

    public boolean AddUser(IUser user) throws SQLException {
        if(repository.save(user)!= null)
            return true;
        return false;
    }
    public boolean get(IUser user) throws SQLException {
        if(repository.getUser(user)!= null)
            return true;
        return false;
    }
    public List<IUser> getAllUsers() throws SQLException {
       List<IUser> users = repository.findAll();
        return users;
    }

}