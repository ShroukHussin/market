package com.swe.services;

import com.swe.model.IUser;

import java.sql.SQLException;
import java.util.List;

public interface IUserServices {

    public boolean AddUser(IUser user) throws SQLException;
    public boolean get(IUser user) throws SQLException;
    public List<IUser> getAllUsers() throws SQLException;
}
