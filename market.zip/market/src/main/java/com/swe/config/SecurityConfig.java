package com.swe.config;

//@EnableWebSecurity

public class SecurityConfig {
}
