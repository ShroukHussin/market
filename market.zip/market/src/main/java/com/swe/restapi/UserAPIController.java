package com.swe.restapi;

import com.swe.model.Admin;
import com.swe.model.Buyer;
import com.swe.model.IUser;
import com.swe.model.Owner;
import com.swe.repository.AdminRepo;
import com.swe.repository.BuyerRepo;
import com.swe.repository.OwnerRepo;
import com.swe.services.IUserServices;
import com.swe.services.UserServices;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class UserAPIController {
   // @Autowired
    IUserServices services ;
    public static  String currentUser;

        @RequestMapping(value = "/register",method= RequestMethod.POST)
    public String Register(@RequestParam("name") String name, @RequestParam("password") String pass, @RequestParam("type") String type) throws SQLException {
            boolean flag = false;

            if (type.equals("owner")) {
                services = new UserServices(new OwnerRepo());
                 flag = services.AddUser(new Owner(name, pass));

            }
            else if(type.equals("buyer"))
            {
                services = new UserServices(new BuyerRepo());
                flag = services.AddUser(new Buyer(name,pass));
            }
            else if(type.equals("admin"))
            {
                services = new UserServices(new AdminRepo());
                flag = services.AddUser(new Admin(name,pass));
            }
            if (flag)
                return "registered successfully";
            else
                return "User already exists";

    }
    @RequestMapping(value = "/login")
    public String login(@RequestParam("name") String name, @RequestParam("password") String pass, @RequestParam("type") String type) throws SQLException {
        boolean flag = false;
        currentUser = type;
        if (type.equals("owner")) {
            services = new UserServices(new OwnerRepo());
            flag = services.get(new Owner(name, pass));

        }
        else if(type.equals("buyer"))
        {
            services = new UserServices(new BuyerRepo());
            flag = services.get(new Buyer(name,pass));
        }
        else if(type.equals("admin"))
        {
            services = new UserServices(new AdminRepo());
            flag = services.get(new Admin(name,pass));
        }
        if (flag)
            return "loged in successfully";
        else
            return "failed to login";

    }
    @RequestMapping(value = "/getAll",produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public List<IUser>  getAll() throws SQLException {
           List<IUser> result = new ArrayList<IUser>();
        List<IUser> result2 = new ArrayList<IUser>();
        List<IUser> result3 = new ArrayList<IUser>();

                services = new UserServices(new OwnerRepo());
                result= services.getAllUsers();
                services = new UserServices(new AdminRepo());
                result2 =services.getAllUsers();
                services = new UserServices(new BuyerRepo());
                result3 =services.getAllUsers();
                result.addAll(result2);
                result.addAll(result3);
                for (int i =0 ; i< result.size(); i++)
                {
                    System.out.println("name= "+result.get(i).getName());
                    System.out.println("pass=  "+result.get(i).getPassword());
                    System.out.println("type=  "+result.get(i).getType());
                }
                return result;



	}

   /*@RequestMapping(value = "/getAllBuyers",method=RequestMethod.POST)
       public List<String>getAllBuyer() throws SQLException {
        services = new UserServices(new BuyerRepo());
        return services.getAllUsers();
    }
*/

}
