package com.swe.repository;

import com.swe.model.IUser;
import com.swe.model.Owner;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OwnerRepo implements IUserRepo {
    public IUser save(IUser user) throws SQLException {
        Statement stmt;
        Connection conn;
        conn = DriverManager.getConnection("jdbc:derby:D:\\3rd year 2nd term\\market\\dbshrouq;create=true");
        stmt = conn.createStatement();
        ResultSet res = ((Statement) stmt).executeQuery("SELECT * FROM owners");
        if (res.equals(null))
            stmt.executeUpdate("Create table owners (name varchar(30) primary key, password varchar(30))");
        res = stmt.executeQuery("SELECT * FROM owners where name = '" + user.getName() + "'");
        if (!res.next()) {
            res = stmt.executeQuery("SELECT * FROM buyers where name = '" + user.getName() + "'");
            if (!res.next())
            {
                res = stmt.executeQuery("SELECT * FROM admins where name = '" + user.getName() + "'");
                if (!res.next())
                {
                    stmt.executeUpdate("insert into owners values ('" + user.getName() + "', '" + user.getPassword() + "')");

                }
            }
            return user;
        }
        return null;
    }



    public IUser getUser(IUser user) throws SQLException {
        Statement stmt;
        Connection conn;
        conn = DriverManager.getConnection("jdbc:derby:D:\\3rd year 2nd term\\market\\dbshrouq;create=true");
        stmt = conn.createStatement();
        ResultSet res ;//= ((Statement) stmt).executeQuery("SELECT * FROM owners");
       /* if (res.equals(null))
            stmt.executeUpdate("Create table owners (name varchar(30) primary key, password varchar(30))");
            */

        res = stmt.executeQuery("SELECT * FROM owners where name = '" + user.getName() + "'");
        if (!res.next())
        {
            return null;
        }
        else
        {
            return user;
        }

    }

    @Override
    public List<IUser> findAll() throws SQLException {
        List<IUser> results = new ArrayList<IUser>();
        Statement stmt;
        Connection conn;
        conn = DriverManager.getConnection("jdbc:derby:D:\\3rd year 2nd term\\market\\dbshrouq;create=true");
        stmt = conn.createStatement();
        ResultSet res = ((Statement) stmt).executeQuery("SELECT * FROM owners");
        while (res.next())
        {
            String name= res.getString("name");
            String pass = res.getString("password");
                IUser usr = new Owner(name,pass);
                results.add(usr);


        }
        if (res.equals(null))
            return null;
        return results;
    }
}
