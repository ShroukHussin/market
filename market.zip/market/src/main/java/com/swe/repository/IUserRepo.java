package com.swe.repository;

import com.swe.model.IUser;

import java.sql.SQLException;
import java.util.List;

public interface IUserRepo {

    IUser save(IUser user) throws SQLException;
    IUser getUser(IUser user) throws SQLException;
    List<IUser> findAll() throws SQLException;
}
