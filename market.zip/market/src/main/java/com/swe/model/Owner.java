package com.swe.model;

public class Owner extends IUser {


    public Owner( String name,String password) {
        super(name,password);
        type="owner";
    }




}