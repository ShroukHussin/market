package com.swe.model;

public abstract class IUser {
    private String name;
    private String password ;
    String type ;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public IUser(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getName() {

        return name;
    }

    public void setPassword(String password) {
        this.password = password;

    }

    public String getPassword() {

        return password;
    }

   /* @Override
    public String toString() {
        return "{" +
                "name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", type=" + type + '\'' +
                '}';
    }*/
}
