package com.swe.model;

public class Buyer extends IUser {


    public Buyer( String name,String password) {
        super(name,password);
        type ="buyer";
    }




}
