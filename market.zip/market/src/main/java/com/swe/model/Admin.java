package com.swe.model;

public class Admin extends IUser {
    public Admin(String name , String password)
    {
        super(name, password);
        type="admin";
    }
}
